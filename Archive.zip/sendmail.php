<?php
// Include Google Cloud dependencies using Composer
require 'vendor/autoload.php';

use Google\Cloud\RecaptchaEnterprise\V1\RecaptchaEnterpriseServiceClient;
use Google\Cloud\RecaptchaEnterprise\V1\Event;
use Google\Cloud\RecaptchaEnterprise\V1\Assessment;
use Google\Cloud\RecaptchaEnterprise\V1\TokenProperties\InvalidReason;

/**
 * Create an assessment to analyze the risk of a UI action.
 * @param string $siteKey Your reCAPTCHA site key
 * @param string $token The user's response token
 * @param string $project Your Google Cloud project ID
 */
function create_assessment(
    string $siteKey,
    string $token,
    string $project
): void {
    // To avoid memory issues, move this client generation outside
    // of this example, and cache it (recommended) or call client.close()
    // before exiting this method.
    $client = new RecaptchaEnterpriseServiceClient();
    $projectName = $client->projectName($project);

    $event = (new Event())
        ->setSiteKey($siteKey)
        ->setToken($token);

    $assessment = (new Assessment())
        ->setEvent($event);

    try {
        $response = $client->createAssessment(
            $projectName,
            $assessment
        );

        // You can use the score only if the assessment is valid,
        // In case of failures like re-submitting the same token, getValid() will return false
        if ($response->getTokenProperties()->getValid() == false) {
            printf('The CreateAssessment() call failed because the token was invalid for the following reason: ');
            printf(InvalidReason::name($response->getTokenProperties()->getInvalidReason()));
        } else {
            printf('The score for the protection action is:');
            printf($response->getRiskAnalysis()->getScore());

            // Optional: You can use the following methods to get more data about the token
            // Action name provided at token generation.
            // printf($response->getTokenProperties()->getAction() . PHP_EOL);
            // The timestamp corresponding to the generation of the token.
            // printf($response->getTokenProperties()->getCreateTime()->getSeconds() . PHP_EOL);
            // The hostname of the page on which the token was generated.
            // printf($response->getTokenProperties()->getHostname() . PHP_EOL);
        }
    } catch (exception $e) {
        printf('CreateAssessment() call failed with the following error: ');
        printf($e);
    }
}

// Your email handling code (contact form) can be placed here, similar to your previous code.

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        !empty($_POST['name'])
        && !empty($_POST['email'])
        && !empty($_POST['message'])
    ) {
        // Form data
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $message = $_POST["message"];

        // Email parameters
        $to = "depriziopaige@gmail.com";
        $subject = "Yay! New Contact Form Submission";
        $body = "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\nMessage: {$message}";
        $headers = "From: {$email}";

        // Check reCAPTCHA
        $recaptcha_secret = "6LeOUxgoAAAAAJcJa6PexmKyVKekry56LTAWfJco";
        $recaptcha_response = $_POST["g-recaptcha-response"];
        $url = "https://www.google.com/recaptcha/api/siteverify?secret=$recaptcha_secret&response=$recaptcha_response";
        $response = file_get_contents($url);
        $response_data = json_decode($response, true);

        if ($response_data["success"]) {
            // reCAPTCHA validation passed, send email
            if (mail($to, $subject, $body, $headers)) {
                // Email sending was successful. You can add additional code here.
                // For example, you can send a confirmation message to the user or perform other actions.
                echo "Message sent successfully!";
            } else {
                echo "Failed to send message.";
            }
        } else {
            echo "reCAPTCHA validation failed. Please complete the reCAPTCHA challenge.";
        }
    }
}

// Replace the following with your actual reCAPTCHA site key, user response token, and Google Cloud project ID
$reCaptchaSiteKey = '6LeOUxgoAAAAAJcJa6PexmKyVKekry56LTAWfJco';
$userResponseToken = 'YOUR_USER_RESPONSE_TOKEN';
$googleCloudProjectId = 'portfolio-paiged-1694456198958';

// Call the create_assessment function with your reCAPTCHA data
create_assessment($reCaptchaSiteKey, $userResponseToken, $googleCloudProjectId);

// Your email handling code continues below.
?>
